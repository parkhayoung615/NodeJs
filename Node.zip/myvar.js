// module.exports.a = 'hello a'

function myvar() {
    this.resMyvar = 'My instance'
    this.hello = 'My instance hello'
}
