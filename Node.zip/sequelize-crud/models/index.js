// .env 파일에 공백이 있으면 안 됨...
const Sequelize = require('sequelize')
const path = require('path')
const fs = require('fs')
const dotenv = require('dotenv').config()

// env 파일에 접근하게 됨
const sequelize = new Sequelize(process.env.DATABASE,
    process.env.DB_USER, process.env.DB_PASSWORD, {
        host: process.env.DB_HOST,
        dialect: 'mysql',
        // 한국 시간
        timezone: '+09',
        operatorsAliases: sequelize.Op,
        pool: {
            max: 5,
            min: 0,
            idle: 10000
        }
    })

let db = []

// 모델 파일을 이용하는 옵션 메소드
fs.readdirSync(__dirname)
    .fillter(file => {
        return file.indexOf('.js') && file != 'index.js'
    })
    .forEach(file => {
        var model = sequelize.import(path.join(__dirname, file))
        db[model.name] = model
    })

Object.keys(db).forEach(modelName => {
    if ("associate" in db[modelName]) {
        db[modelName].associate(db)
    }
})

db.sequelize = sequelize
db.Sequelize = Sequelize

module.exports = db