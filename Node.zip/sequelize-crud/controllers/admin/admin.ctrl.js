const models = require('../../models') // ORM 불러오기

exports.get_products = (_, res) => {
    // res.render( 'admin/products.html' , 
    //     { message : "hello" } // message 란 변수를 템플릿으로 내보낸다.
    // );

    // models.Products.findByCK

    // models.Products.update(req.body{
    //     where : {id : req.params.id}
    // })
    // 이렇게 업데이트 해주면 됨

    // models.Products.destory(req.body{
    //     where : {id : req.params.id}
    // })
    // 이렇게 삭제 해주면 됨


    models.Products.findAll({

    }).then((products) => {
        res.render('admin/products.html', {products});
    })
}

exports.get_products_write = (_, res) => {
    res.render('admin/write.html');
}

exports.post_products_write = (req, res) => {
    // res.send(req.body);

    // models.Products.create({
    //     name: req.body.name,
    //     price: req.body.price,
    //     description: req.body.description
    // }).then(() => {
    //     res.redirect('/admin/products')
    // })
    // 아래랑 같음 줄여줄 수 있다는 뜻

    models.Products.create(req.body).then(() => {
        res.redirect('/admin/products')
    })
}
// 라우팅 주소 : 슬래시로 시작
// require 할 때 : 점으로 시작
