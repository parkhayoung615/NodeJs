// const myvar = require('./myvar')
// sonsole.log(myvar.a)

module.exports = myvar


console.log(setVar.name)
console.log(setVar.hello)